

import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';

import { lightsPage } from '../pages/lights/lights';
import { sensorsPage } from '../pages/sensors/sensors';
import { HomePage } from '../pages/home/home';
import { TabsPage } from '../pages/tabs/tabs';
import {SettingsPage} from '../pages/settings/settings';
import {AuthPage} from '../pages/auth/auth';
import {DataLogPage} from '../pages/data-log/data-log';
import { PopoverPage} from '../pages/lights/lights';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import {MQTTService} from '../core/mqtt.service';
import {LoggerService} from '../core/logger.service';
import { ThemeSettingProvider } from '../providers/theme-setting/theme-setting';

@NgModule({
  declarations: [
    MyApp,
    lightsPage,
    sensorsPage,
    HomePage,
    TabsPage,
    SettingsPage,
    AuthPage,
    DataLogPage,
    PopoverPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    lightsPage,
    sensorsPage,
    HomePage,
    SettingsPage,
    TabsPage,
    AuthPage,
    DataLogPage,
    PopoverPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    MQTTService,
    LoggerService,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    ThemeSettingProvider
  ]
})
export class AppModule {}
