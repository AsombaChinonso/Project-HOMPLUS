import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { LoadingController } from 'ionic-angular';

@Component({
  selector: 'page-contact',
  templateUrl: 'sensors.html'
})
export class sensorsPage {

	public tap = '2';
  selectedSegment: string = 'hot';

  constructor(public navCtrl: NavController, public loadingCtrl: LoadingController) {

  }

  tapEvent($event){
  	this.refreshToast();
  }

  refreshToast() {
    const loader = this.loadingCtrl.create({
      content: "Please wait...",
      duration: 3000
    });
    loader.present();
  }


}
