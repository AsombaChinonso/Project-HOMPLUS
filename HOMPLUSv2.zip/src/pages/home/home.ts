import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ToastController } from 'ionic-angular';

import {AuthPage} from '../auth/auth';


@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController, public toastCtrl: ToastController) {

  }

  authClicked(){
  	this.navCtrl.push(AuthPage,{

  	})
  }

  

  connectToast() {
    const toast = this.toastCtrl.create({
      message: 'Device Connected!',
      duration: 3000
    });
    toast.present();
  }

  disconnectToast() {
    const toast = this.toastCtrl.create({
      message: 'Device Disconnected',
      duration: 3000
    });
    toast.present();
  }


  // Slides View
  slides = [
    {
      title: "HOMPLUS",
      description: "An <b> Ionic IOT Comfort Lamp</b> Your trusted smart lighting solutions.",
      image: "assets/imgs/light-bulb.png",
    },
    {
      title: "What is HOMPLUS?",
      description: "<b>HOMPLUS</b> is easy to use smart lamp, simply download the app and play with the lamp, it is suitable for reading, camping, outdoor events and more.",
      image: "assets/imgs/ica-slidebox-img-2.png",
    },
    {
      title: "Do you know?",
      description: "<b>HOMPLUS</b> comes with 3 different dynamic light sources, a tempreture sensor, humidity sensor, set a timer to turn ON the lamp, you could vary its brightness and change its color to suit your prefrence.",
      image: "assets/imgs/glasses.png",
    }
  ];

}

// engineered with technologies and protocol such as Ionic v2, CloudMQTT, Wifi