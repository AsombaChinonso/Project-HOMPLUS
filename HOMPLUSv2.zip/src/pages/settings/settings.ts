import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

// import {AuthPage} from '../auth/auth';
// import {DataLogPage} from '../data-log/data-log';
import { ToastController } from 'ionic-angular';
import { AlertController } from 'ionic-angular';

import {ThemeSettingProvider} from  './../../providers/theme-setting/theme-setting';



@IonicPage()
@Component({
  selector: 'page-settings',
  templateUrl: 'settings.html',
})
export class SettingsPage {

  testRadioOpen: boolean;
  testRadioResult;
  selectedTheme: String;

  constructor(public navCtrl: NavController, 
    public navParams: NavParams, 
    private themeSettings: ThemeSettingProvider,
    public themeToast:ToastController,
    public alertCntl:AlertController) {
      this.themeSettings.getActiveTheme().subscribe(val => this.selectedTheme = val);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SettingsPage');
  }

  toggleAppTheme(){
    if(this.selectedTheme == 'dark-theme'){
      this.themeSettings.setActiveTheme('light-theme');
      this.toast();
    }else{
      this.themeSettings.setActiveTheme('dark-theme');
      this.toast();
    }

  }

// Theme Toast!
toast() {
    const toast = this.themeToast.create({
      message: 'Theme Changed!',
      duration: 2000
    });
    toast.present();
  }


//Security Alert Box
changePassword(){
  let prompt = this.alertCntl.create({
      title: 'Secure Your App',
      message: "Please set passcode for this app, passcode must be maximum of four (4) digits, your product ID is necessary for security reasons!",
      inputs: [
        {
          name: 'Product Id',
          placeholder: 'Enter your product Id'
        },
        {
          name: 'New PassCode',
          placeholder: 'Enter your passcode'
        }
      ],

      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Save',
          handler: data => {
            console.log('Saved clicked');
          }
        }
      ]
    });
    prompt.present();
}

// Theme Change Alert
changeTheme(testRadioResult){
   let alert = this.alertCntl.create();
    alert.setTitle('Change App Theme');

    alert.addInput({
      type: 'radio',
      label: 'Default-Theme',
      value: 'light-theme',
      checked: this.testRadioResult === "light-theme"
    });

    alert.addInput({
      type: 'radio',
      label: 'Dark-Theme',
      value: 'dark-theme',
      checked: this.testRadioResult === "dark-theme"
    });

    alert.addInput({
      type: 'radio',
      label: 'Cordova-Purple',
      value: 'purple-theme',
      checked: this.testRadioResult === "purple-theme"
    });

    alert.addInput({
      type: 'radio',
      label: 'Flash-Theme',
      value: 'green-theme',
      checked: this.testRadioResult === "green-theme"
    });

    

    alert.addButton('Cancel');
    alert.addButton({
      text: 'Ok',
      handler: data => {
        console.log('Theme data:', data);
        this.testRadioOpen = false;
        this.testRadioResult = data;

       


        if(this.selectedTheme == 'dark-theme'){
          this.themeSettings.setActiveTheme(this.testRadioResult);
          this.toast();

        }

        if(this.selectedTheme == 'light-theme'){
          this.themeSettings.setActiveTheme(this.testRadioResult);
          this.toast();
        }

        if(this.selectedTheme == 'purple-theme'){
          this.themeSettings.setActiveTheme(this.testRadioResult);
          this.toast();
        }

        if(this.selectedTheme == 'green-theme'){
          this.themeSettings.setActiveTheme(this.testRadioResult);
          this.toast();
        }

      }
    });

    alert.present().then(() => {
      this.testRadioOpen = true;
    });
}


///Error Theme Alert
errorAlert() {
    let alert = this.alertCntl.create({
      title: 'Error!',
      message: 'Theme not Found!',
      buttons: ['Ok']
    });
    alert.present()
  }













  // authClicked(){
  // 	this.navCtrl.push(AuthPage,{
  		
  // 	})
  // }

  // dataLogClicked(){
  //   this.navCtrl.push(DataLogPage,{
      
  //   })
  // }

}
