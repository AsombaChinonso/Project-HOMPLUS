import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage';
import { AlertController } from 'ionic-angular';


@Injectable()
export class PasswordProvider {
	

  constructor(private storageBank: Storage, public alertCntl:AlertController) {
   
  }

  getUserDetails(){
  	//return storageBank.get()
  }

  setUserPasscode(data){
  	this.storageBank.set('passcode', data);
  }

  setUserPid(data){
    this.storageBank.set('productID', data);
  }

  changeUserDetailsAndPassword(){
  let prompt = this.alertCntl.create({
      title: 'Secure Your App',
      message: "Please set passcode for this app, passcode must be maximum of four (4) digits, your product ID is necessary for security reasons!",
      inputs: [
        {
          name: 'productId',
          placeholder: 'Your default product-Id is HOMPLUS'
        },
        {
          name: 'code',
          placeholder: 'Enter your new PassCode'
        }
      ],

      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Save Code',
          handler: data => {
            if (data.code.length < 4 && data.productId != 'HOMPLUS' ) {
              return false;
            }else{
              this.setUserPasscode(data.code);
              this.setUserPid(data.productId);
              return true;
            }
          }
        }
      ]
    });
    prompt.present();
}

}
