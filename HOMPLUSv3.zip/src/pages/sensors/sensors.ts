import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { LoadingController } from 'ionic-angular';

import {AuthPage} from '../auth/auth';
import {DataLogPage} from '../data-log/data-log';
import {SettingsPage} from '../settings/settings';

@Component({
  selector: 'page-contact',
  templateUrl: 'sensors.html'
})
export class sensorsPage {



  constructor(public navCtrl: NavController,
              public loadingCtrl: LoadingController) {

  }

   authClicked(){
      this.navCtrl.push(AuthPage,{
        
      })
    }

    dataLogClicked(){
      this.navCtrl.push(DataLogPage,{
        
      })
    }

    userAccountClicked(){
      this.navCtrl.push(SettingsPage,{
        
      })
    }


}
