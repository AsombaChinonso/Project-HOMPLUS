import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DataLogPage } from './data-log';

@NgModule({
  declarations: [
    DataLogPage,
  ],
  imports: [
    IonicPageModule.forChild(DataLogPage),
  ],
})
export class DataLogPageModule {}
