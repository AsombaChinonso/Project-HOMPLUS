import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ToastController } from 'ionic-angular';
import { LoadingController } from 'ionic-angular';
import { AlertController } from 'ionic-angular';
import { LockScreenComponent } from 'ionic-simple-lockscreen';

import { MQTTService } from '../../core/mqtt.service';
import { LoggerService } from '../../core/logger.service';
import {PasswordProvider} from  './../../providers/password/password';

import {Platform} from 'ionic-angular';
import { PopoverController } from 'ionic-angular';
import { NavParams } from 'ionic-angular';
import { Storage } from '@ionic/storage';


// import {sensorsPage} from '../sensors/sensors';
// import {SettingsPage} from '../settings/settings';




@Component({
  template: `
       <ion-item class="statusCard">
        <ion-avatar item-start>
            <img src="assets/imgs/avatar-finn.png">
          </ion-avatar>
          <button item-end ion-item large clear icon-end  detail-none class="text-button text-smaller" (click)="lockApp()">Lock App</button>
        </ion-item> 
  `
})

export class PopoverPage {


  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              private storageBank: Storage,
              public toastCtrl: ToastController) {

  }

 

  ngOnInit() {

  }


  lockApp(){
    this.storageBank.get('passcode').then( code => {
      this.navCtrl.push(LockScreenComponent,{
        code: code,
        ACDelbuttons:false,
        passcodeLabel:'Unlock App',
        onCorrect: () => {
          let toast = this.toastCtrl.create({
            message: 'App Unlocked!',
            duration: 2000
          });
          toast.present(); 
        },
        onWrong: (attempts) => {
          let toast = this.toastCtrl.create({
            message: `${attempts} wrong passcode attempt(s)`,
            duration: 2000
          });
          toast.present(); 
        }
      })
    });
    
  }

}

















@Component({
  selector: 'page-about',
  templateUrl: 'lights.html'
})
export class lightsPage {

  public value: any = {};
  public value2: any = {};
  public value3: any = {};

  public homeConnected: boolean = false;
  public relayStatus = 'Offline';

  public tap = '2';
  selectedSegment: string = 'hot';

  constructor(public navCtrl: NavController, 
              public toastCtrl: ToastController,
              public loadingCtrl: LoadingController, 
              public alertCntl: AlertController,
              public mqtt:MQTTService, 
              public logger:LoggerService, 
              public platform: Platform,
              private popoverCtrl: PopoverController,
              private storageBank: Storage,
              public lockProviderPage: PasswordProvider
              ) {

            //TELL A NEW USER TO SETUP HIS/HER APP PASSWORD
            this.platform.ready().then(() => {
              this.storageBank.get('passcode').then(code => {
                  if (!code){
                      this.lockProviderPage.changeUserDetailsAndPassword();
                  }
              });
            })

            // Connects to cloudMQTT when platform is ready!
              this.platform.pause.subscribe(() => {

                  this.logger.log(`Receive event: pause`);
                  this.mqtt.disconnect();
              });

              this.platform.resume.subscribe(() => {

                  this.logger.log(`Receive event: resume`);
                  this.mqtt.connect();
              });

              this.connect();

            }


  // light_state_one
  get relay1PowerOnModel(){
    return this.value.powerOn ? this.value.powerOn : false;
  }

  set relay1PowerOnModel(newvalue){
    this.value.powerOn = newvalue;
    console.log(this.value);

    this.mqtt.publish('/relay/1', newvalue ? 'on' : 'off', {retain: true, qos: 2});

    if (this.value.powerOn == false) {
      this.light_state_one_OFF();
    }else{
      this.light_state_one_ON();
    }
    
  }

  // light_state_two
  get relay2PowerOnModel(){
    return this.value2 ? this.value2 : false;
  }

  set relay2PowerOnModel(newvalue){
    this.value2 = newvalue;
    console.log(this.value2);

    if (this.value2 == false) {
      this.light_state_two_OFF();
    }else{
      this.light_state_two_ON();
    }

    
  }


  // light_state_three
  get relay3PowerOnModel(){
    return this.value3 ? this.value3 : false;
  }

  set relay3PowerOnModel(newvalue){
    this.value3 = newvalue;
    console.log(this.value3);

    if (this.value3 == false) {
      this.light_state_three_OFF();
    }else{
      this.light_state_three_ON();
    }

    
  }


// Connection Confirmation Toast!
connect(){
    

    this.mqtt.connect(err => {
            if (err) return;

            this.logger.log(`connect: MQTT connected`);

            this.homeConnected = true;


            this.mqtt.subscribe('/relay/1', (topic: string, powerOn: string) => {

                if (this.value.powerOn !== (powerOn === 'on')) {

                    this.value.powerOn = powerOn === 'on';
                }
            });

            this.connectToast();
    
            this.relayStatus = 'Online';
        });

  }

  disconnect(){
    

    this.mqtt.disconnect(err => {
            if (err) return;

            this.logger.log(`disconnect: MQTT disconnect`);

            this.disconnectToast();
            this.homeConnected = false;
            this.relayStatus = 'Offline';
        });
  }

  // lock app
  


// ///////////// LOCK TOAST ////////////////////////
lockToast() {
    const toast = this.toastCtrl.create({
      message: 'App Locked!',
      duration: 2000
    });
    toast.present();
  }

connectToast() {
    const loader = this.loadingCtrl.create({
      content: "Connecting to Device...",
      duration: 3000
    });
    loader.present();
  }

  disconnectToast() {
    const toast = this.toastCtrl.create({
      message: 'Device Disconnected',
      duration: 3000
    });
    toast.present();
  }
  // End of Connection Confirmation Toast!








// light_state_one
  light_state_one_ON() {
    const toast = this.toastCtrl.create({
      message: 'Side Light ON!',
      duration: 2000
    });
    toast.present();
  }

  light_state_one_OFF() {
    const toast = this.toastCtrl.create({
      message: 'Side Light OFF!',
      duration: 2000
    });
    toast.present();
  }

  // light_state_one ENDS HERE


  light_state_two_ON() {
    const toast = this.toastCtrl.create({
      message: 'Touch Light ON!',
      duration: 2000
    });
    toast.present();
  }

  light_state_two_OFF() {
    const toast = this.toastCtrl.create({
      message: 'Touch Light OFF!',
      duration: 2000
    });
    toast.present();
  }

  light_state_three_ON() {
    const toast = this.toastCtrl.create({
      message: 'CampLamp ON!',
      duration: 2000
    });
    toast.present();
  }

  light_state_three_OFF() {
    const toast = this.toastCtrl.create({
      message: 'CampLamp OFF!',
      duration: 2000
    });
    toast.present();
  }


  // Sensors Data Page
   tapEvent($event){
    this.refreshToast();
  }

  refreshToast() {
    const loader = this.loadingCtrl.create({
      content: "Please wait...",
      duration: 3000
    });
    loader.present();
  }


  // PopOver page
  presentPopover(ev) {

    let popover = this.popoverCtrl.create(PopoverPage, {
      
    });

    popover.present({
      ev: ev
    });
  }

   warnings = [
    {
      title: "HOMPLUS",
      description: "An <b> Ionic IOT Comfort Lamp</b> Your trusted smart lighting solutions.",
      image: "assets/imgs/warning.png",
    }
  ];

  moreSetting(){
    this.navCtrl.push(sensorsPage,{
      
    })
  }

}
