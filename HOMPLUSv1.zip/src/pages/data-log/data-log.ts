import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import {LoggerService} from '../../core/logger.service';

/**
 * Generated class for the DataLogPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-data-log',
  templateUrl: 'data-log.html',
})
export class DataLogPage {

	// public messages = [
	// 	'Side light OFF',
	// 	'Touch light OFF',
	// 	'CampLamp light ON',
	// 	'Side light ON',
	// 	'Touch light OFF',
	// 	'CampLamp light OFF',
	// 	'Side light OFF',
	// 	'Touch light ON',
	// 	'CampLamp light ON',
	// 	'Tempreture is 20 Degree',
	// 	'Humidity is 17%',
	// 	'Tempreture is 25 Degree',
	// 	'Voltage Output is 12v',
	// 	'Humidity is 19%'
	// ];

	messages: string[];

  constructor(public navCtrl: NavController, public navParams: NavParams, public logger: LoggerService) {

  	this.messages = logger.getMessages();

        setInterval(() => {
            this.messages = logger.getMessages();
        }, 100);
  	
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad DataLogPage');
  }

 

}
