import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import {AuthPage} from '../auth/auth';
import {DataLogPage} from '../data-log/data-log';

/**
 * Generated class for the SettingsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-settings',
  templateUrl: 'settings.html',
})
export class SettingsPage {

	appVersion ='';

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  	this.appVersion = '1.0.0';
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SettingsPage');
  }

  authClicked(){
  	this.navCtrl.push(AuthPage,{
  		
  	})
  }

  dataLogClicked(){
    this.navCtrl.push(DataLogPage,{
      
    })
  }

}
